export default function Journal() {
  return <div className="text-center text-gray-500">Module Journal will appear here.</div>;
}
