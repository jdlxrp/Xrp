export default function Portfolio() {
  return <div className="text-center text-gray-500">Module Portfolio will appear here.</div>;
}
