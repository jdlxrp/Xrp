export default function Alerts() {
  return <div className="text-center text-gray-500">Module Alerts will appear here.</div>;
}
