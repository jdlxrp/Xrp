export default function Candles() {
  return <div className="text-center text-gray-500">Module Candles will appear here.</div>;
}
