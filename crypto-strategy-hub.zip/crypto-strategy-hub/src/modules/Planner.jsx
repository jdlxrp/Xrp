export default function Planner() {
  return <div className="text-center text-gray-500">Module Planner will appear here.</div>;
}
